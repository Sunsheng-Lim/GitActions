# Nus-moneyapp

View app at https://cotldus.github.io/nus-moneyapp-frontend/

Dummy user:

    "username": "Anatole",
    "password": "WOfNDBm"
   
Other users: https://nus-moneyapp-backend.herokuapp.com/user/all
